package psa.naloga1;

public class NodeBinarno {
    private static int counter;
    private int key;
    NodeBinarno left;
    NodeBinarno right;

    public NodeBinarno(int key) {
        this.key = key;
        this.left = null;
        this.right = null;
    }

    public static NodeBinarno addNode(NodeBinarno root, int key){
        if (root==null){
            return new NodeBinarno(key);
        }else if (key<root.key){
            root.left=addNode(root.left, key);
        }else if (key>root.key){
            root.right=addNode(root.right, key);
        }else {
            return root;
        }
        return root;
    }

    public static NodeBinarno deleteNode(NodeBinarno root, int key) {
        if (root == null) {
            return null;
        }
        if (key == root.key) {
            if (root.left == null && root.right == null) {
                return null;
            } else if (root.right == null) {
                return root.left;
            } else if (root.left == null) {
                return root.right;
            }
            int smallest = smallestNode(root.right);
            root.key = smallest;
            root.right = deleteNode(root.right, smallest);
            return root;
        } else if (key < root.key) {
            root.left = deleteNode(root.left, key);
            return root;
        }
        root.right = deleteNode(root.right, key);
        return root;
    }

    // trditev ?(preveri resničnosti) (drži):(ne drži)
    private static int smallestNode(NodeBinarno root){
        return root.left == null ? root.key : smallestNode(root.left);
    }

    public static boolean searchNode(NodeBinarno root, int key){
        if (root==null){
            return false;
        }else if (root.key==key){
            return true;
        }else {
            return key<root.key ? searchNode(root.left,key) : searchNode(root.right,key);
        }
    }

    public int compare(NodeBinarno node) {
        counter++;
        return node.key - this.key;
    }

    public int getCounter() {
        return counter;
    }

    public void resetCounter() {
        counter=0;
    }
}
