package psa.naloga1;

public class NodeSeznam {
    private static int counter;
    private int key;
    NodeSeznam next;

    public NodeSeznam(int key) {
        this.key = key;
        this.next = null;
    }

    public static NodeSeznam addNode(NodeSeznam head,int key){
        if (head==null){
            NodeSeznam nodeSeznam = new NodeSeznam(key);
            return nodeSeznam;
        }else {
            return head.next= new NodeSeznam(key);
        }
    }

    public static void deleteNode(NodeSeznam head, int key){
        NodeSeznam tmp = head, prev = null;
        if (tmp != null && tmp.key == key) {
            head = tmp.next;
            return;
        }
        while (tmp != null && tmp.key != key) {
            prev = tmp;
            tmp = tmp.next;
        }
        if (tmp == null){
            return;
        }
        prev.next = tmp.next;
    }

    public static boolean searchNode(NodeSeznam head, int key){
        if (head==null){
            return false;
        }else if (head.key==key){
            return true;
        }else {
            return searchNode(head.next,key);
        }
    }

    public int compare(NodeSeznam node) {
        counter++;
        return node.key - this.key;
    }

    public int getCounter() {
        return counter;
    }

    public void resetCounter() {
        counter=0;
    }
}
