package psa.naloga1;

public class Binarno {
    private NodeBinarno root;

    /*
     * Metoda sprejme celo stevilo in ga vstavi v drevo. Ce element ze obstaja v drevesu, vrne false
     * Metoda vrne true, ce je bil element uspesno vstavljen in false sicer.
     */
    public boolean insert(int element) {
        if (search(element)){
            return false;
        }else {
            root= NodeBinarno.addNode(root,element);
            return true;
        }
    }

    /*
     * Metoda sprejme celo stevilo in izbrise element iz drevesa.
     * Metoda vrne true, ce je bil element uspesno izbrisan iz drevesa, in false sicer
     */
    public void delete(int element) {
        root= NodeBinarno.deleteNode(root, element);
    }

    /*
     * Metoda sprejme celo stevilo in poisce element v drevesu.
     * Metoda vrne true, ce je bil element uspesno najden v drevesu, in false sicer
     */
    public boolean search(int element) {
        return NodeBinarno.searchNode(root,element);
    }

    public int getCounter() {
        return root != null?root.getCounter():null;
    }

    public void resetCounter() {
        if (root != null)
            root.resetCounter();
    }
}
